<?php
include 'db.php';
$result = $conn->query("SELECT * FROM posts ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Post Management</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
<h1>Post Management</h1>
<a href="create.php" class="btn">+ Add New Post</a>
<table>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Content</th>
        <th>Created At</th>
        <th>Actions</th>
    </tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['title'] ?></td>
        <td><?=$row['content']?></td>
        <td><?= $row['created_at'] ?></td>
        
        <td>
            <a href="edit.php?id=<?= $row['id'] ?>"class="edit-link">Edit</a>
           <button type="button" class="btn btn-sm btn-danger delete-btn" data-id="<?= $row['id'] ?>">Delete</button>


        </td>
    </tr>
    <?php endwhile; ?>
</table>
<script src="ajax.js"></script>
</body>
</html>