<?php
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $stmt = $conn->prepare("INSERT INTO posts (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);
    $stmt->execute();
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Post</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Create Post</h1>
<form method="POST">
    <label>Title</label>
    <input type="text" name="title" required>
    <label>Content</label>
    <textarea name="content" required></textarea>
    <button type="submit">Save</button>
</form>
</body>
</html>