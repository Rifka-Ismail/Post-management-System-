document.addEventListener('click', function(e) {
    if (e.target.classList.contains('delete-btn')) {
        let id = e.target.getAttribute('data-id');
        if (confirm('Delete this post?')) {
            fetch('delete.php', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: new URLSearchParams({ id: id })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    // Remove row instantly
                    e.target.closest('tr').remove();
                } else {
                    alert(data.error || 'Delete failed');
                }
            })
            .catch(err => {
                console.error(err);
                alert('Error deleting post');
            });
        }
    }
});
