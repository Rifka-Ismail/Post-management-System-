<?php
include 'db.php';
$id = $_GET['id'];
$post = $conn->query("SELECT * FROM posts WHERE id=$id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $stmt = $conn->prepare("UPDATE posts SET title=?, content=? WHERE id=?");
    $stmt->bind_param("ssi", $title, $content, $id);
    $stmt->execute();
    header("Location: index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Post</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h1>Edit Post</h1>
<form method="POST">
    <label>Title</label>
    <input type="text" name="title" value="<?= $post['title'] ?>" required>
    <label>Content</label>
    <textarea name="content" required><?= $post['content'] ?></textarea>
    <button type="submit">Update</button>
</form>
</body>
</html>